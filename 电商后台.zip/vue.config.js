module.exports={
    devServer: {
        port: 5050,
        open: true
    },
}