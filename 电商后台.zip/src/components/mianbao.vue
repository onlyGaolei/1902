<template>
  <div>
    <el-breadcrumb separator="/" v-for="(v, i) in meta" :key="i">
      <el-breadcrumb-item>{{ v.name }}</el-breadcrumb-item>
      <el-breadcrumb-item>{{ v.title }}</el-breadcrumb-item>
    </el-breadcrumb>
  </div>
</template>

<script>
export default {
  data() {
    return {
      meta: [],
    };
  },
  created() {
    // console.log(this.$route.meta);
    this.meta = this.$route.meta;
  },
};
</script>

<style lang="less">
</style>