<template>
  <div>
    <div class="top">
      <mian />
    </div>
    用户标签
    <div>
      <el-button type="primary" icon="el-icon-plus" @click="Tian"
        >添加标签</el-button
      >
    </div>
    <div>
      <el-dialog
        :title="title"
        :visible.sync="dialogVisible"
        width="30%"
        :before-close="handleClose"
      >
        <span> </span>
        <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button
            type="primary"
            @click="title === '编辑' ? editOk() : addOk()"
            >确 定</el-button
          >
        </span>
      </el-dialog>
    </div>
    <div>
      <el-table :data="tableData" border style="width: 100%">
        <el-table-column fixed prop="id" label="ID" width="150">
        </el-table-column>
        <el-table-column prop="label_name" label="分组名字"> </el-table-column>
        <el-table-column label="操作" fixed="right">
          <template slot-scope="scope">
            <el-button
              type="text"
              size="small"
              @click="handleEdit(scope.$index, scope.row)"
              >编辑</el-button
            >
            <el-button
              type="text"
              size="small"
              @click="handleDelete(scope.$index, scope.row)"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div>
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="[5, 10, 15]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      >
      </el-pagination>
    </div>
  </div>
</template>
<script>
import mian from "../components/mianbao.vue";
import { userFourData,  } from "../api/index";
export default {
  data() {
    return {
      title: "",
      tableData: [],
      dialogVisible: false,
      currentPage: 1,
      page: 1,
      limit: 5,
      total: 0,
    };
  },
  created() {
    userFourData({ page: this.page, limit: this.limit }).then((res) => {
      // console.log(res);
      this.tableData = res.data.list;
      this.total = res.data.count;
    });
    
  },
  components: {
    mian,
  },
  methods: {
    Tian() {
      this.dialogVisible = true;
      this.title = "添加";
    },
    handleClose() {
      this.dialogVisible = false;
    },
    handleEdit(index, row) {
      this.dialogVisible = true;
      this.title = "编辑";
      console.log(index, row);
    },
    handleDelete(index, row) {
      console.log(index, row);
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      userFourData({ page: this.page, limit: val }).then((res) => {
        // console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      userFourData({ page: val, limit: this.limit }).then((res) => {
        // console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
  },
};
</script>
<style lang="less">
</style>