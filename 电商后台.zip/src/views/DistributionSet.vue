<template>
  <div class="fenxiao">
    <div class="top">
      <mian />
    </div>
    <div class="Box">
      <span>{{ title }}</span>
      <span>
        <!-- v-for="(v, i) in data" :key="i" -->
        <el-form ref="form" :model="form" label-width="150px">
          <el-form-item label="分销启用">
            <!-- <el-radio-group
              v-model="form.status1"
              v-for="(v, i) in data1.options"
              :key="i"
            >
              <el-radio :label="v.label" :value="v.value">{{
                v.label
              }}</el-radio>
            </el-radio-group> -->
            <el-radio
              v-model="form.brokerage_func_status"
              v-for="(v, i) in data1.options"
              :key="i"
              :label="v.value"
              :value="v.value"
            >
              {{ v.label }}
            </el-radio>
          </el-form-item>
          <el-form-item label="分销关系绑定">
            <!-- <el-radio-group> -->
            <el-radio
              v-model="form.brokerage_bindind"
              v-for="(v, i) in data2.options"
              :key="i"
              :label="v.value"
              :value="v.value"
              >{{ v.label }}</el-radio
            >
            <!-- <el-radio label="新用户">新用户</el-radio> -->
            <!-- </el-radio-group> -->
          </el-form-item>
          <el-form-item label="分销模式">
            <el-radio-group
              v-model="form.store_brokerage_statu"
              v-for="(v, i) in data3.options"
              :key="i"
            >
              <el-radio :label="v.value" :value="v.value">{{
                v.label
              }}</el-radio>
              <!-- <el-radio label="人人分销">人人分销</el-radio> -->
              <!-- <el-radio label="满额分销">满额分销</el-radio> -->
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="data4.title" style="width: 550px">
            <el-input v-model="form.store_brokerage_ratio"></el-input>
          </el-form-item>
          <el-form-item :label="data5.title" style="width: 550px">
            <el-input v-model="form.store_brokerage_two"></el-input>
          </el-form-item>
          <el-form-item :label="data5.title" style="width: 550px">
            <el-input v-model="form.user_extract_min_price"></el-input>
          </el-form-item>
          <el-form-item :label="data7.title" style="width: 550px">
            <el-input type="textarea" v-model="form.user_extract_bank"></el-input>
          </el-form-item>
          <el-form-item :label="data8.title" style="width: 550px">
            <el-input v-model="form.extract_time"></el-input>
          </el-form-item>
          <el-form-item :label="data9.title" style="width: 550px">
            <el-input v-model="form.store_brokerage_price"></el-input>
          </el-form-item>
        </el-form>
      </span>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="BtnOk()">提交</el-button>
      </span>
    </div>
  </div>
</template>

<script>
import mian from "../components/mianbao.vue";
import { DistributionSetData, DistributionSetedit } from "../api/index";
export default {
  data() {
    return {
      title: "",
      form: {
        brokerage_func_status: "",
        brokerage_bindind: "",
        store_brokerage_statu: "",
        store_brokerage_ratio: "",
        store_brokerage_two: "",
        user_extract_min_price: "",
        name4: "",
        user_extract_bank: "",
        extract_time: "",
        store_brokerage_price: "",
      },
      data1: [],
      data2: [],
      data3: [],
      data4: [],
      data5: [],
      data6: [],
      data7: [],
      data8: [],
      data9: [],
    };
  },
  components: {
    mian,
  },
  created() {
    DistributionSetData().then((res) => {
      console.log(res);
      this.title = res.data.title;
      this.data1 = res.data.rules[0];
      this.data2 = res.data.rules[1];
      this.data3 = res.data.rules[2];
      this.data4 = res.data.rules[3];
      this.data5 = res.data.rules[4];
      this.data6 = res.data.rules[5];
      this.data7 = res.data.rules[6];
      this.data8 = res.data.rules[7];
      this.data9 = res.data.rules[8];
      this.form = {
        brokerage_func_status: res.data.rules[0].value,
        brokerage_bindind: res.data.rules[1].value,
        store_brokerage_statu: res.data.rules[2].value,
        store_brokerage_ratio: res.data.rules[3].value,
        store_brokerage_two: res.data.rules[4].value,
        user_extract_min_price: res.data.rules[5].value,
        user_extract_bank: res.data.rules[6].value,
        extract_time: res.data.rules[7].value,
        store_brokerage_price: res.data.rules[8].value,
      };
    });
  },
  methods: {
    BtnOk() {
      console.log("submit!");
      DistributionSetedit(this.form).then((res) => {
        console.log(res);
      });
    },
  },
};
</script>

<style lang="less">
.fenxiao {
  width: 100%;
  .Box {
    width: 100%;
    height: auto;
    // border: 1px solid red;
  }
}
</style>