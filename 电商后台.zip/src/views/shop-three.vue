<template>
  <div>
    <div class="top">
      <mian />
    </div>
    商品添加
  </div>
</template>
<script>
import mian from "../components/mianbao.vue";
export default {
  data() {
    return {};
  },
  created() {},
  components: {
    mian,
  },
};
</script>
<style lang="less">
</style>