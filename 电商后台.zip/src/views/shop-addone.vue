<template>
  <div>
    <div>
      <el-button icon="el-icon-arrow-left" @click="Btnfan">返回</el-button>
    </div>
    <div>
      <el-tabs v-model="activeName" @tab-click="handleClick">
        <el-tab-pane label="商品信息" name="first">
          <span>
            <el-form ref="form" :model="form" label-width="150px">
              <el-form-item label="商品名称：" style="width: 550px">
                <el-input v-model="form.name1"></el-input>
              </el-form-item>
              <el-form-item label="商品分类：" style="width: 550px">
                <el-select v-model="form.region" placeholder="请选择">
                  <el-option label="区域一" value="shanghai"></el-option>
                  <el-option label="区域二" value="beijing"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="商品关键字：" style="width: 550px">
                <el-input v-model="form.name2"></el-input>
              </el-form-item>
              <el-form-item label="商品简介：" style="width: 550px">
                <el-input type="textarea" v-model="form.desc"></el-input>
              </el-form-item>
            </el-form>
          </span>
          <span slot="footer" class="dialog-footer">
            <el-button type="primary" @click="OkFun">确 定</el-button>
          </span>
        </el-tab-pane>
        <el-tab-pane label="商品详情" name="second">商品详情</el-tab-pane>
        <el-tab-pane label="其他设置" name="third">其他设置</el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      activeName: "first",
      form: {
        name1: "",
        name2: "",
        region: "",
        desc: "",
      },
    };
  },
  created() {},
  methods: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
    //返回上一页
    Btnfan() {
      this.$router.push("/admin/product/product_list");
    },
    OkFun() {
      console.log(1);
    },
  },
};
</script>

<style lang="less">
</style>