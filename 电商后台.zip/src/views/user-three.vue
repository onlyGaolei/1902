<template>
  <div>
    <div class="top">
      <mian />
    </div>
    用户分组
    <div></div>
    <div>
      <el-table :data="tableData" border style="width: 100%">
        <el-table-column fixed prop="id" label="ID" width="150">
        </el-table-column>
        <el-table-column prop="group_name" label="分组名字" width="120">
        </el-table-column>
        <el-table-column label="操作" fixed="right">
          <template slot-scope="scope">
            <el-button
              type="text"
              size="small"
              @click="handleEdit(scope.$index, scope.row)"
              >编辑</el-button
            >
            <el-button
              type="text"
              size="small"
              @click="handleDelete(scope.$index, scope.row)"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div>
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="[3, 6, 9]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      >
      </el-pagination>
    </div>
  </div>
</template>
<script>
import mian from "../components/mianbao.vue";
import { userThreeData } from "../api/index";
export default {
  data() {
    return {
      title: "",
      tableData: [],
      dialogVisible: false,
      currentPage: 1,
      page: 1,
      limit: 15,
      total: 0,
    };
  },
  created() {
    userThreeData({ page: this.page, limit: this.limit }).then((res) => {
      console.log(res);
      this.tableData = res.data.list;
      this.total = res.data.count;
    });
  },
  components: {
    mian,
  },
  methods: {
    handleEdit(index, row) {
      this.dialogVisible = true;
      this.title = "编辑";
      console.log(index, row);
    },
    handleDelete(index, row) {
      console.log(index, row);
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      userThreeData({ page: this.page, limit: val }).then((res) => {
        console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      userThreeData({ page: val, limit: this.limit }).then((res) => {
        console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
  },
};
</script>
<style lang="less">
</style>