<template>
  <div>
    <div class="top">
      <mian />
    </div>
    会员等级
    <div>
      <el-button type="primary" @click="btnFun">添加</el-button>
    </div>
    <div>
      <el-table :data="tableData" border style="width: 100%">
        <el-table-column fixed prop="id" label="ID" width="150">
        </el-table-column>
        <el-table-column prop="name" label="等级名称" width="120">
        </el-table-column>
        <el-table-column prop="explain" label="等级说明" width="120">
        </el-table-column>
        <el-table-column label="操作" fixed="right">
          <template slot-scope="scope">
            <el-button
              type="text"
              size="small"
              @click="handleEdit(scope.$index, scope.row)"
              >编辑</el-button
            >
            <el-button
              type="text"
              size="small"
              @click="handleDelete(scope.$index, scope.row)"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div>
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="[3, 6, 9]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      >
      </el-pagination>
    </div>
    <div>
      <el-dialog
        :title="title"
        :visible.sync="dialogVisible"
        width="30%"
        :before-close="handleClose"
      >
        <span>这是一段信息</span>
        <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="bianFun()">确 定</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import mian from "../components/mianbao.vue";
import { userTwoData } from "../api/index";
export default {
  data() {
    return {
      title: "",
      tableData: [],
      dialogVisible: false,
      currentPage: 1,
      page: 1,
      limit: 15,
      total: 0,
    };
  },
  created() {
    userTwoData({ page: this.page, limit: this.limit }).then((res) => {
      console.log(res);
      this.tableData = res.data.list;
      this.total = res.data.count;
    });
  },
  components: {
    mian,
  },
  methods: {
    handleEdit(index, row) {
      this.dialogVisible = true;
      this.title = "编辑";
      console.log(index, row);
    },
    handleDelete(index, row) {
      console.log(index, row);
    },
    btnFun() {
      this.title = "添加";
      this.dialogVisible = true;
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      userTwoData({ page: this.page, limit: val }).then((res) => {
        console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      userTwoData({ page: val, limit: this.limit }).then((res) => {
        console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
    //X关闭遮罩层
    handleClose() {
      this.dialogVisible = false;
    },
  },
};
</script>
<style lang="less">
</style>