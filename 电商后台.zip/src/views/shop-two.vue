<template>
  <div>
    <div class="top">
      <mian />
    </div>
    商品分类
    <div>
      商品分类：
      <el-select
        v-model="value1"
        clearable
        placeholder="请选择"
        @change="fenleiFun"
      >
        <el-option
          v-for="item in tableData"
          :key="item.value"
          :label="item.label"
          :value="item.cate_name"
        >
        </el-option>
      </el-select>
      状态：<el-select
        clearable
        v-model="value2"
        placeholder="请选择"
        @change="isShowFun"
      >
        <el-option
          v-for="item in status"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        >
        </el-option>
      </el-select>
      分类名称：<el-input
        v-model="input"
        placeholder="请输入内容"
        style="width: 200px"
      ></el-input>
      <el-button @click="cha" type="primary" icon="el-icon-search"></el-button>
      <div>
        <el-dialog
          :title="title"
          :visible.sync="dialogVisible"
          width="30%"
          :before-close="handleClose"
        >
          <span>
            <el-form ref="form" :model="form" label-width="80px">
              <el-form-item label="父级">
                <el-select
                  v-model="form.pid"
                  clearable
                  placeholder="请选择"
                  @change="fenleiFun"
                >
                  <el-option
                    v-for="item in zhela.options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="分类名称">
                <el-input v-model="form.cate_name"></el-input>
              </el-form-item>
              <el-form-item label="分类图标">
                <el-upload
                  class="avatar-uploader"
                  action="http://bw.gsruiying.com.cn/adminapi/file/category?name=item.file.name"
                  :show-file-list="false"
                  :http-request="onshang"
                  :on-success="handleAvatarSuccess"
                  :before-upload="beforeAvatarUpload"
                >
                  <img v-if="form.pic" :src="form.pic" class="avatar" />
                  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
              </el-form-item>
              <el-form-item label="排序">
                <el-input-number
                  v-model="form.sort"
                  controls-position="right"
                  @change="handleChange"
                >
                </el-input-number>
              </el-form-item>
              <el-form-item label="状态" label-width="120px">
                <el-radio
                  v-model="form.is_show"
                  v-for="(v, i) in radio.options"
                  :key="i"
                  :label="v.value"
                  :value="v.value"
                >
                  {{ v.label }}
                </el-radio>
              </el-form-item>
            </el-form>
          </span>
          <span slot="footer" class="dialog-footer">
            <el-button @click="dialogVisible = false">取 消</el-button>
            <el-button
              type="primary"
              @click="title === '编辑' ? editFunok() : addFunok()"
              >确 定</el-button
            >
          </span>
        </el-dialog>
      </div>
      <div>
        <el-button type="primary" icon="el-icon-plus" @click="addFun"
          >添加</el-button
        >
      </div>
      <el-table
        :data="tableData"
        style="width: 100%"
        row-key="id"
        border
        :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
      >
        <el-table-column type="index" width="50"> </el-table-column>
        <el-table-column prop="cate_name" label="分类名称" width="180">
        </el-table-column>
        <el-table-column prop="pic" label="分类图标" width="180">
          <template slot-scope="scope">
            <div>
              <img :src="scope.row.pic" alt="" />
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="sort" label="分类排序" width="180">
        </el-table-column>
        <el-table-column prop="address" label="分类状态">
          <template slot-scope="scope">
            <el-switch
              :value="scope.row.is_show === 1 ? true : false"
              @change="statusFun(scope.row)"
            >
            </el-switch>
          </template>
        </el-table-column>
        <el-table-column label="操作" fixed="right">
          <template slot-scope="scope">
            <el-button
              type="text"
              size="small"
              @click="handleEdit(scope.$index, scope.row)"
              >编辑</el-button
            >
            <el-button
              type="text"
              size="small"
              @click="handleDelete(scope.$index, scope.row)"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
import mian from "../components/mianbao.vue";
import {
  shop_twoOne,
  shop_twoTWo,
  shop_edit,
  shop_twoUplad,
  addok,
  shop_Del,
  shop_editFun,
  shop_top,
} from "../api/index";
import http from "../utils/http";
export default {
  data() {
    return {
      form: {
        name: "",
        region: "",
        num: "",
        radio: "隐藏",
        pic: "",
      },
      input: "",
      title: "",
      tableData: [],
      dialogVisible: false,
      value1: "",
      value2: "",
      valuefulei: "",
      status: [
        {
          value: 1,
          label: "显示",
        },
        {
          value: 0,
          label: "隐藏",
        },
      ],
      page: 1,
      limit: 10,
      zhela: [],
      select: [],
      frame: [],
      inputNumber: [],
      radio: [],
      newid: "",
    };
  },
  created() {
    this.show();
  },
  components: {
    mian,
  },
  methods: {
    show() {
      shop_twoOne({
        is_show: this.value2,
        cate_name: this.value1,
        page: this.page,
        limit: this.limit,
      }).then((res) => {
        // console.log(res);
        this.tableData = res.data.list;
      });
    },
    cha() {
      shop_twoOne({
        is_show: this.value2,
        cate_name: this.input,
        page: this.page,
        limit: this.limit,
      }).then((res) => {
        // console.log(res);
        this.tableData = res.data.list;
      });
    },
    //上传
    onshang(item) {
      // console.log(item);
      let formData = new FormData();
      formData.append("file", item.file);
      formData.append("group", "system");
      return shop_twoUplad({
        data: formData, // 选择FormData方式传参
      })
        .then((data) => {
          console.log(data);
        })
        .catch((err) => {
          console.log(err, "error");
        });
    },
    //上传的事件
    handleAvatarSuccess(res, file) {
      this.form.pic = URL.createObjectURL(file.raw);
    },
    //上传的事件
    beforeAvatarUpload(file) {
      const isJPG = file.type.indexOf("image/");
      const isLt2M = file.size;
      if (isJPG == -1) {
        this.$message.error(
          "文件格式错误，请上传图片类型,如：JPG，PNG后缀的文件。"
        );
      }
      if (!isLt2M) {
        this.$message.error("上传头像图片大小不能超过 2MB!");
      }
      return isJPG && isLt2M;
    },
    //数量计算
    handleChange(value) {
      // console.log(value);
    },
    handleClose(done) {
      this.dialogVisible = false;
    },
    //添加显示遮罩层
    addFun() {
      this.dialogVisible = true;
      this.title = "添加";
      shop_top().then((res) => {
        console.log(res);
        this.zhela = res.data.rules[0];
        this.select = res.data.rules[0];
        this.frame = res.data.rules[2];
        this.inputNumber = res.data.rules[3];
        this.radio = res.data.rules[4];
        this.form = {
          cate_name: res.data.rules[1].value,
          is_show: res.data.rules[4].value,
          pic: res.data.rules[2].value,
          pid: res.data.rules[0].value,
          sort: res.data.rules[3].value,
        };
      });
    },
    //添加提交
    addFunok() {
      this.dialogVisible = false;
      addok(this.form).then((res) => {
        console.log(res);
        this.show();
      });
    },
    //商品分类搜索
    fenleiFun() {
      shop_twoOne({
        is_show: this.value2,
        cate_name: this.value1,
        page: this.page,
        limit: this.limit,
      }).then((res) => {
        // console.log(res);
        this.tableData = res.data.list;
      });
    },
    //table状态
    isShowFun() {
      console.log(this.value2);
      shop_twoOne({
        is_show: this.value2,
        cate_name: this.value1,
        page: this.page,
        limit: this.limit,
      }).then((res) => {
        // console.log(res);
        this.tableData = res.data.list;
      });
    },
    //显示编辑遮罩层
    handleEdit(index, row) {
      console.log(index, row);
      this.dialogVisible = true;
      this.title = "编辑";
      // this.form.name = row.cate_name;
      // this.form.num = row.sort;
      // this.form.pic = row.pic;
      // this.form.radio = row.is_show ? "显示" : "隐藏";
      this.newid = row.id;
      shop_editFun(row.id).then((res) => {
        console.log(res);
        this.zhela = res.data.rules[0];
        this.select = res.data.rules[0];
        this.frame = res.data.rules[2];
        this.inputNumber = res.data.rules[3];
        this.radio = res.data.rules[4];
        this.form = {
          cate_name: res.data.rules[1].value,
          is_show: res.data.rules[4].value,
          pic: res.data.rules[2].value,
          pid: res.data.rules[0].value,
          sort: res.data.rules[3].value,
        };
      });
    },
    //编辑提交
    editFunok() {
      console.log(this.form);
      console.log(this.newid);
      shop_edit({ id: this.newid, data: this.form }).then((res) => {
        console.log(res);
        this.show();
      });
      this.dialogVisible = false;
    },
    //删除
    handleDelete(index, row) {
      console.log(index, row);
      shop_Del(row.id).then((res) => {
        console.log(res);
        this.show();
      });
    },
    //状态
    statusFun(item) {
      console.log(item);
      http
        .put(
          `/adminapi/product/category/set_show/${item.id}/${
            item.is_show ? 0 : 1
          }`
        )
        .then((res) => {
          console.log(res);
          this.status = res.msg;
          this.show();
        });
    },
  },
};
</script>
<style lang="less">
img {
  width: 50px;
  height: 50px;
}

.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}

.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}

.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}

.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
</style>