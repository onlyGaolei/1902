<template>
  <div>
    <div class="top">
      <mian />
    </div>
    商品规格
    <div>
      <el-button type="primary" icon="el-icon-plus" @click="btnFun"
        >添加</el-button
      >
      <el-input type="" v-model="input" style="width: 200px" />
      <el-button type="primary" icon="el-icon-search" @click="souFun"
        >搜索</el-button
      >
    </div>
    <div>
      <el-table :data="tableData" border style="width: 100%">
        <el-table-column fixed prop="id" label="ID" width="150">
        </el-table-column>
        <el-table-column prop="rule_name" label="规格名称" width="120">
        </el-table-column>
        <el-table-column prop="rule_value" label="商品属性" width="120">
          <template slot-scope="scope">
            <div v-for="(x, y) in scope.row.attr_value" :key="y">
              <p>{{ x }}</p>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="rule_value" label="商品属性" width="120">
          <template slot-scope="scope">
            <div v-for="(x, y) in JSON.parse(scope.row.rule_value)" :key="y">
              <p>{{ x.value }}</p>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="操作" fixed="right">
          <template slot-scope="scope">
            <el-button
              type="text"
              size="small"
              @click="handleEdit(scope.$index, scope.row)"
              >编辑</el-button
            >
            <el-button
              type="text"
              size="small"
              @click="handleDelete(scope.$index, scope.row)"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div>
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="[5, 10, 15]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      >
      </el-pagination>
    </div>
    <div>
      <el-dialog
        :title="title"
        :visible.sync="dialogVisible"
        width="30%"
        :before-close="handleClose"
      >
        <span>
          <el-form ref="form" :model="form" label-width="80px">
            <el-form-item label="标题名称">
              <el-input v-model="form.rule_name"></el-input>
            </el-form-item>
            <el-form-item label="规格名称">
              <el-input v-model="form.attr_value"></el-input>
            </el-form-item>
            <!-- <el-form-item label="规格值">
              <el-input v-model="form.rule_value"></el-input>
            </el-form-item> -->
          </el-form>
        </span>
        <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button
            type="primary"
            @click="title === '编辑' ? bianFun() : tianjiaFun()"
            >确 定</el-button
          >
        </span>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import mian from "../components/mianbao.vue";
import { shop_fourOne, shop_fiveDelete, shop_fiveTian } from "../api/index";
import http from "../utils/http";
export default {
  data() {
    return {
      form: {
        rule_name: "",
        attr_name: "",
        attr_value: "",
        rule_value: "",
      },
      input: "",
      title: "",
      tableData: [],
      dialogVisible: false,
      currentPage: 1,
      page: 1,
      limit: 5,
      total: 0,
      newid: "",
    };
  },
  created() {
    shop_fourOne({ page: this.page, limit: this.limit }).then((res) => {
      console.log(res);
      this.tableData = res.data.list;
      this.total = res.data.count;
    });
  },
  components: {
    mian,
  },
  methods: {
    souFun() {
      console.log(this.input);
      shop_fourOne({
        page: this.page,
        limit: this.limit,
        rule_name: this.input,
      }).then((res) => {
        // console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
    handleEdit(index, row) {
      this.dialogVisible = true;
      this.title = "编辑";
      this.newid = row.id;
      console.log(index, row);
    },
    //删除
    handleDelete(index, row) {
      console.log(index, row);
      shop_fiveDelete({ ids: row.id }).then((res) => {
        console.log(res);
      });
    },
    //添加显示遮罩层
    btnFun() {
      this.title = "添加";
      this.dialogVisible = true;
    },
    // 添加提交
    tianjiaFun() {
      console.log("添加提交");
      this.dialogVisible = false;
      shop_fiveTian({
        rule_name: this.form.rule_name,
        spec: [{ value: this.form.attr_value, detail: ["第一个", "第二个"] }],
      }).then((res) => {
        console.log(res);
      });
    },
    //编辑提交
    bianFun() {
      console.log("编辑提交");
      this.dialogVisible = false;
    },
    //X关闭遮罩层
    handleClose() {
      this.dialogVisible = false;
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      shop_fourOne({ page: this.page, limit: val }).then((res) => {
        console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      shop_fourOne({ page: val, limit: this.limit }).then((res) => {
        console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
  },
};
</script>
<style lang="less">
</style>