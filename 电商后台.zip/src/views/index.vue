<template>
  <div class="index">
    index
    <div class="top">
      <dl v-for="(v,i) in data" :key="i">
        <dt>
          <p>
            <span>{{v.title}}</span>
            <el-tag type="success">{{v.date}}</el-tag>
          </p>
        </dt>
        <dd>
          <p>{{v.week}}</p>
          <p>日同比{{v.today_ratio}} 周同比{{v.today}}%</p>
          <p>
            <span>{{v.total_name}}</span>
            <span>{{v.total}}</span>
          </p>
        </dd>
      </dl>
      <!-- <dl>
        <dt>
          <p>
            <span>用户访问量</span>
            <el-tag type="success">昨日</el-tag>
          </p>
        </dt>
        <dd>
          <p>1</p>
          <p>日同比100% 周同比0%</p>
          <p>
            <span>总访问量</span>
            <span>9Pv</span>
          </p>
        </dd>
      </dl>
      <dl>
        <dt>
          <p>
            <span>订单量</span>
            <el-tag type="success">昨日</el-tag>
          </p>
        </dt>
        <dd>
          <p>0</p>
          <p>日同比0% 周同比0%</p>
          <p>
            <span>总订单量</span>
            <span>0单</span>
          </p>
        </dd>
      </dl>
      <dl>
        <dt>
          <p>
            <span>新增用户</span>
            <el-tag type="success">昨日</el-tag>
          </p>
        </dt>
        <dd>
          <p>0</p>
          <p>日同比0% 周同比0%</p>
          <p>
            <span>总销售额</span>
            <span>9人</span>
          </p>
        </dd>
      </dl> -->
    </div>
    <div class="cen">
      <dl>
        <dt><i class="el-icon-user-solid"></i></dt>
        <dd>用户管理</dd>
      </dl>
      <dl>
        <dt><i class="el-icon-user-solid"></i></dt>
        <dd>系统设置</dd>
      </dl>
      <dl>
        <dt><i class="el-icon-user-solid"></i></dt>
        <dd>商品</dd>
      </dl>
      <dl>
        <dt><i class="el-icon-user-solid"></i></dt>
        <dd>订单管理</dd>
      </dl>
      <dl>
        <dt><i class="el-icon-user-solid"></i></dt>
        <dd>短信配置</dd>
      </dl>
      <dl>
        <dt><i class="el-icon-user-solid"></i></dt>
        <dd>文章管理</dd>
      </dl>
      <dl>
        <dt><i class="el-icon-user-solid"></i></dt>
        <dd>分销管理</dd>
      </dl>
      <dl>
        <dt><i class="el-icon-user-solid"></i></dt>
        <dd>优惠券</dd>
      </dl>
    </div>
    <div class="foot">
      <i class="el-icon-user-solid"></i>
      订单
    </div>
    <div class="foo">
      订单趋势
    </div>
  </div>
</template>

<script>
import {indexTopFun} from '../api/index'
export default {
  data(){
    return{
      data:[]
    }
  },
  created(){
    indexTopFun().then((res)=>{
      // console.log(res);
      this.data=res.data.info
    })
  }
};
</script>

<style lang="less">
.index {
  width: 100%;
  .top {
    width: 100%;
    display: flex;
    dl {
      flex: 1;
      height: 100%;
      box-sizing: border-box;
      padding: 20px;
      border: 1px solid #eee;
      margin: 0 10px;
      dt {
        width: 100%;
        height: 50px;

        p {
          display: flex;
          justify-content: space-between;
        }
      }
      dd {
        width: 100%;
        display: flex;
        flex-direction: column;
        p {
          width: 100%;
          display: flex;
          justify-content: space-between;
        }
      }
    }
  }
  .cen {
    width: 100%;
    display: flex;
    dl {
      width: 100%;
      dt {
        width: 100%;
        height: 50px;
      }
      dd {
        width: 100%;
        display: flex;
        justify-content: space-between;
      }
    }
  }
  .foot{
    width: 100%;
    height: 50px;
    border-bottom: 1px solid #ccc;
  }
  .foo{
    width: 100%;
    height: 350px;
    border-bottom: 1px solid #ccc;
    line-height: 50px;
  }
}
</style>