<template>
  <div class="order-one">
    <div class="top">
      <mian />
    </div>
    订单
    <div class="top_two">
      <p>全部(0)</p>
      <p>普通订单(0)</p>
      <p>拼团订单(0)</p>
      <p>秒杀订单(0)</p>
      <p>砍价订单(0)</p>
    </div>
    <div>
      订单状态：
      <el-radio-group v-model="radio" @change="changeDate">
        <el-radio-button label="">全部</el-radio-button>
        <el-radio-button label="today">今天</el-radio-button>
        <el-radio-button label="yesterday">昨天</el-radio-button>
        <el-radio-button label="lately7">最近7天</el-radio-button>
        <el-radio-button label="lately30">最近30天</el-radio-button>
        <el-radio-button label="month">本月</el-radio-button>
        <el-radio-button label="year">本年</el-radio-button>
      </el-radio-group>
    </div>
    <div>
      <el-button type="primary" @click="btnFun">订单核销</el-button>
    </div>
    <div>
      <el-table :data="tableData" border style="width: 100%">
        <el-table-column fixed prop="id" label="ID" width="150">
        </el-table-column>
        <el-table-column prop="rule_name" label="商品规格" width="120">
        </el-table-column>
        <!-- <el-table-column prop="rule_value" label="商品属性" width="120">
        </el-table-column> -->
        <el-table-column label="操作" fixed="right">
          <template slot-scope="scope">
            <el-button
              type="text"
              size="small"
              @click="handleEdit(scope.$index, scope.row)"
              >编辑</el-button
            >
            <el-button
              type="text"
              size="small"
              @click="handleDelete(scope.$index, scope.row)"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div>
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="[3, 6, 9]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      >
      </el-pagination>
    </div>
  </div>
</template>
<script>
import mian from "../components/mianbao.vue";
import { orderData, orderTop } from "../api/index";
export default {
  data() {
    return {
      tableData: [],
      dialogVisible: false,
      currentPage: 1,
      page: 1,
      limit: 15,
      total: 0,
      radio: "",
    };
  },
  created() {
    orderTop().then((res) => {
      //   console.log(res);
    });
    orderData({ page: this.page, limit: this.limit }).then((res) => {
      console.log(res);
      this.tableData = res.data.data;
      this.total = res.data.count;
    });
  },
  components: {
    mian,
  },
  methods: {
    changeDate() {
      // console.log(this.radio);
      // this.data = this.radio;
    },
    handleEdit(index, row) {
      this.dialogVisible = true;
      this.title = "编辑";
      console.log(index, row);
    },
    handleDelete(index, row) {
      console.log(index, row);
    },
    //添加显示遮罩层
    btnFun() {
      this.title = "添加";
      this.dialogVisible = true;
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      orderData({ page: this.page, limit: val }).then((res) => {
        console.log(res);
        this.tableData = res.data.data;
        this.total = res.data.count;
      });
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      orderData({ page: val, limit: this.limit }).then((res) => {
        console.log(res);
        this.tableData = res.data.data;
        this.total = res.data.count;
      });
    },
  },
};
</script>
<style lang="less">
.order-one {
  width: 100%;
  .top {
    width: 100%;
    height: 30px;
  }
  .top_two {
    width: 100%;
    display: flex;
    justify-content: space-between;
    border-bottom: 1px solid #ccc;
  }
}
</style>