<template>
  <div class="shop-one">
    <div class="top">
      <mian />
    </div>
    商品管理
    <div class="top_two">
      <!-- <p v-for="(v, i) in top" :key="i">{{ v.name }}({{ v.count }})</p> -->
      <el-tabs v-model="activeName" @tab-click="handleClick">
        <el-tab-pane
          v-for="(v, i) in top"
          :key="i"
          :label="v.name + `(${v.count})`"
          :name="String(v.type)"
        >
          <!-- 表格 -->
          <div>
            商品分类：
            <el-select v-model="value" placeholder="请选择" @change="sou1">
              <el-option
                v-for="item in cha"
                :key="item.value"
                :label="item.label"
                :value="item.cate_name"
              >
              </el-option>
            </el-select>
            商品搜索：<input type="text" v-model="input" />
            <el-button type="primary" icon="el-icon-search" @click="sou"
              >搜索</el-button
            >
          </div>
          <div>
            <el-button type="primary" icon="el-icon-plus" @click="TianAdd">添加</el-button>
            <el-button
              type="success"
              data-v-54c9df3e=""
              class="bnt mr15 ivu-btn ivu-btn-success"
            >
              <span>复制淘宝、天猫、拼多多、京东、苏宁</span>
            </el-button>
            <el-button icon="el-icon-upload">导出</el-button>
          </div>
          <div>
            <el-table :data="tableData" style="width: 100%">
              <el-table-column type="expand">
                <template slot-scope="props">
                  <el-form
                    label-position="left"
                    inline
                    class="demo-table-expand"
                  >
                    <el-form-item label="商品分类：">
                      <span>{{ props.row.cate_name }}</span>
                    </el-form-item>
                  </el-form>
                </template>
              </el-table-column>
              <el-table-column label="商品 ID" prop="id"> </el-table-column>
              <el-table-column label="商品 ID" prop="image">
                <template slot-scope="scope">
                  <div>
                    <img :src="scope.row.image" alt="" />
                  </div>
                </template>
              </el-table-column>
              <el-table-column
                label="商品名称"
                prop="store_name"
              ></el-table-column>
              <el-table-column label="商品售价" prop="price"></el-table-column>
              <el-table-column label="状态" prop="is_show">
                <template slot-scope="scope">
                  <el-switch
                    :value="scope.row.is_show === 1 ? true : false"
                    @change="statusFun(scope.row)"
                  >
                  </el-switch>
                </template>
              </el-table-column>
              <el-table-column label="操作" fixed="right">
                <template slot-scope="scope">
                  <el-button
                    type="text"
                    size="small"
                    @click="handleEdit(scope.$index, scope.row)"
                    >编辑</el-button
                  >
                  <el-button
                    v-if="Number(activeName) !== 6"
                    type="text"
                    size="small"
                    @click="handleDelete(scope.$index, scope.row)"
                    >移动到回收站</el-button
                  >
                  <el-button
                    v-else
                    type="text"
                    size="small"
                    @click="handleDelete(scope.$index, scope.row)"
                    >恢复商品</el-button
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div>
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-sizes="[3, 6, 9]"
              :page-size="100"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total"
            >
            </el-pagination>
          </div>
          <!--  -->
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>
<script>
import mian from "../components/mianbao.vue";
import {
  shop_oneOne,
  shop_oneTwo,
  shop_oneThree,
  huishouzhan,
} from "../api/index";
import http from "../utils/http";
export default {
  data() {
    return {
      input: "",
      value: "",
      cha: [],
      top: [],
      activeName: "1",
      tableData: [],
      currentPage: 1,
      page: 1,
      limit: 3,
      total: 0,
    };
  },
  created() {
    
    // 商品管理数据
    shop_oneThree().then((res) => {
      // console.log(res);
      this.cha = res.data;
    });
    this.show();
    this.shua()
  },
  methods: {
    //添加
    TianAdd(){
      this.$router.push('/shop-addone')
    },
    shua(){
      shop_oneOne().then((res) => {
      // console.log(res);
      this.top = res.data.list;
    });
    },
    show() {
      shop_oneTwo({
        page: this.page,
        limit: this.limit,
        cate_id: 0,
        type: Number(this.activeName),
        store_name: this.searchbox,
        excel: 0,
        sales: "asc",
      }).then((res) => {
        // console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
    sou1() {
      shop_oneTwo({
        page: this.page,
        limit: this.limit,
        cate_id: 0,
        type: Number(this.activeName),
        store_name: this.value,
        excel: 0,
        sales: "asc",
      }).then((res) => {
        // console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
    //商品管理搜索
    sou() {
      console.log(1);
      shop_oneTwo({
        page: this.page,
        limit: this.limit,
        cate_id: 0,
        type: Number(this.activeName),
        store_name: this.input,
        excel: 0,
        sales: "asc",
      }).then((res) => {
        // console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
    statusFun(item) {
      http
        .put(
          `/adminapi/product/product/set_show/${item.id}/${
            item.is_show ? 0 : 1
          }`
        )
        .then((res) => {
          console.log(res);
          this.show();
        });
    },
    handleClick(tab, event) {
      // console.log(tab, event);
      shop_oneTwo({
        page: this.page,
        limit: this.limit,
        cate_id: 0,
        type: Number(this.activeName),
        store_name: this.searchbox,
        excel: 0,
        sales: "asc",
      }).then((res) => {
        // console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
    //编辑
    handleEdit(index, row) {
      // this.dialogVisible = true;
      // this.title = "编辑";
      console.log(index, row);
    },
    //移入回收站
    handleDelete(index, row) {
      console.log(row);
      huishouzhan(row.id).then((res) => {
        console.log(res);
        this.show();
        this.shua()
      });
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      shop_oneTwo({
        page: this.page,
        limit: val,
        cate_id: 0,
        type: Number(this.activeName),
        store_name: this.searchbox,
        excel: 0,
        sales: "asc",
      }).then((res) => {
        console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      shop_oneTwo({
        page: val,
        limit: this.limit,
        cate_id: 0,
        type: Number(this.activeName),
        store_name: this.searchbox,
        excel: 0,
        sales: "asc",
      }).then((res) => {
        console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
  },
  components: {
    mian,
  },
};
</script>
<style lang="less">
.shop-one {
  width: 100%;

  .top {
    width: 100%;
    height: 30px;
  }

  img {
    width: 50px;
    height: 50px;
  }

  .top_two {
    width: 100%;
    // display: flex;
    // justify-content: space-between;
    // border-bottom: 1px solid #ccc;
  }
}
</style>