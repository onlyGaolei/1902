<template>
  <div>
    <div class="top">
      <mian />
    </div>
    用户管理
    <div>
      <el-tabs v-model="activeName" @tab-click="handleClick">
        <el-tab-pane label="全部" name="first">
          <div>
            <div>
              <!-- <el-button @click="tianFun">添加</el-button> -->
              <input type="text" v-model="value" />
              <button @click="sou">搜索</button><button>重置</button>
            </div>
            <el-table :data="tableData" style="width: 100%">
              <el-table-column
                type="selection"
                width="55"
                @selection-change="all_Btn"
              >
              </el-table-column>
              <!-- <el-table-column label="#" type="index" width="50"> </el-table-column> -->
              <el-table-column
                prop="uid"
                label="ID"
                width="180"
              ></el-table-column>
              <el-table-column prop="avatar" label="头像" width="180">
                <template slot-scope="scope">
                  <div class="img">
                    <img :src="scope.row.avatar" alt="" />
                  </div>
                </template>
              </el-table-column>
              <el-table-column
                prop="real_name"
                label="姓名"
                width="180"
              ></el-table-column>
              <el-table-column
                prop="level"
                label="会员等级"
                width="180"
              ></el-table-column>
              <el-table-column
                prop="group_id"
                label="分组"
                width="180"
              ></el-table-column>
              <el-table-column
                prop="spread_uid_nickname"
                label="推荐人"
                width="180"
              ></el-table-column>
              <el-table-column
                prop="user_type"
                label="用户类型"
                width="180"
              ></el-table-column>
              <el-table-column
                prop="now_money"
                label="余额"
                width="180"
              ></el-table-column>

              <el-table-column label="操作">
                <template slot-scope="scope">
                  <el-button
                    size="mini"
                    @click="handleEdit(scope.$index, scope.row)"
                    >编辑</el-button
                  >
                  <el-button
                    size="mini"
                    type="danger"
                    @click="handleDelete(scope.$index, scope.row)"
                    >删除</el-button
                  >
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div>
            <el-dialog
              :title="title"
              :visible.sync="dialogVisible"
              width="30%"
              :before-close="handleClose"
            >
              <span>
                <el-form
                  ref="form"
                  :model="form"
                  label-width="90px"
                  v-for="(v, i) in editBox"
                  :key="i"
                >
                  <el-form-item :label="v.title">
                    <el-input v-model="v.value"></el-input>
                  </el-form-item>
                </el-form>
              </span>
              <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="edit()">确 定</el-button>
              </span>
            </el-dialog>
          </div>
          <div>
            <el-pagination
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-sizes="[3, 6, 9]"
              :page-size="100"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total"
            >
            </el-pagination>
          </div>
        </el-tab-pane>
        <el-tab-pane label="配置管理" name="second">配置管理</el-tab-pane>
        <el-tab-pane label="角色管理" name="third">角色管理</el-tab-pane>
        <el-tab-pane label="定时任务补偿" name="fourth"
          >定时任务补偿</el-tab-pane
        >
      </el-tabs>
    </div>
  </div>
</template>
<script>
import mian from "../components/mianbao.vue";
import { userData, edit } from "../api/index";
export default {
  data() {
    return {
      value: "",
      title: "",
      tableData: [],
      dialogVisible: false,
      currentPage: 1,
      page: 1,
      limit: 3,
      total: 0,
      activeName: "first",
      edit_Fun: [],
      editBox: [],
      form: {
        value: "",
      },
    };
  },
  created() {
    userData({
      page: this.page,
      limit: this.limit,
    }).then((res) => {
      console.log(res);
      this.tableData = res.data.list;
      this.total = res.data.count;
    });
  },
  components: {
    mian,
  },
  methods: {
    handleClose() {
      this.dialogVisible = false;
    },
    //编辑确定
    edit() {
      this.dialogVisible = false;
      // editFun({ value: this.value }).then((res) => {
      //   console.log(res);
      // });
    },
    //编辑回填
    handleEdit(index, row) {
      // console.log(index, row);
      edit(row.uid).then((res) => {
        console.log(res);
        this.title = res.data.title;
        this.editBox = res.data.rules;
      });
      this.dialogVisible = true;
    },
    handleDelete(index, row) {
      console.log(index, row);
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      userData({
        page: this.page,
        limit: val,
      }).then((res) => {
        console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      userData({
        page: val,
        limit: this.limit,
      }).then((res) => {
        console.log(res);
        this.tableData = res.data.list;
        this.total = res.data.count;
      });
    },
    handleClick(tab, event) {
      console.log(tab, event);
    },
    //全选
    all_Btn() {},
    sou() {
      console.log("搜索");
      this.tableData = this.tableData.filter((v) => {
        return v.real_name.indexOf(this.value) != -1;
      });
    },
  },
};
</script>
<style lang="less">
img {
  width: 70px;
  height: 70px;
}
</style>