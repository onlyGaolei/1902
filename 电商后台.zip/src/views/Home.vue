<template>
  <div class="home">
    <div class="top">
      <el-container>
        <el-aside width="200px">
          <el-row class="tac">
            <el-col :span="24">
              <el-menu default-active="2" class="el-menu-vertical-demo" background-color="#545c64" text-color="#fff"
                active-text-color="#ffd04b" :unique-opened="is_open" router>
                <!-- <el-submenu
                  :index="String(index)"
                  v-for="(v, index) in menus"
                  :key="index"
                >
                  <template slot="title">
                    <i class="el-icon-location"></i>
                    <span>{{ v.title }}</span>
                  </template>
                  <el-menu-item-group v-for="(x, y) in v.children" :key="y">
                    <el-menu-item @click="addTab(editableTabsValue, x)">
                      <router-link :to="x.path">{{ x.title }}</router-link>
                    </el-menu-item>
                  </el-menu-item-group>
                </el-submenu> -->
                <div v-for="(v, i) in menus" :key="i">
                  <el-menu-item v-if="!v.children" @click="addTab(editableTabsValue, v)">
                    <router-link :to="v.path">{{ v.title }}</router-link>
                  </el-menu-item>
                  <el-submenu :index="String(i)" v-else>
                    <template slot="title">
                      <i class="el-icon-location"></i>
                      <span>{{ v.title }}</span>
                    </template>
                    <el-menu-item-group v-for="(x, y) in v.children" :key="y">
                      <el-menu-item v-if="!x.children" @click="addTab(editableTabsValue, x)">
                        <router-link :to="x.path">{{ x.title }}</router-link>
                      </el-menu-item>
                      <!--  -->
                      <el-submenu :index="x.path" v-else>
                        <template slot="title">
                          <span>{{ x.title }}</span>
                        </template>
                          <el-menu-item  v-for="(a, b) in x.children" :key="b">
                            <router-link :to="a.path">{{ a.title }}</router-link>
                          </el-menu-item>
                      </el-submenu>
                      <!--  -->
                    </el-menu-item-group>
                  </el-submenu>
                </div>
              </el-menu>
            </el-col>
          </el-row>
        </el-aside>
        <el-main>
          <!-- 中间布局 -->
          <div style="margin-bottom: 20px"></div>
          <el-tabs v-model="editableTabsValue" type="card" closable @tab-remove="removeTab" @tab-click="jump">
            <el-tab-pane v-for="item in editableTabs" :key="item.name" :label="item.title" :name="item.name">
              {{ item.content }}
            </el-tab-pane>
          </el-tabs>
          <router-view />
          <!--  -->
        </el-main>
      </el-container>
    </div>
    <div class="foot"></div>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        is_open: false,
        menus: [],
        editableTabsValue: "2",
        editableTabs: [],
        tabIndex: 2,
      };
    },
    created() {
      // console.log(this);
      // console.log(this.$store.state.menus);
      this.menus = this.$store.state.menus;
      //获取动态tab切换
      let arr = JSON.parse(sessionStorage.getItem("tabs"));
      // console.log(arr);
      if (arr) {
        this.editableTabs = arr;
      }
    },
    methods: {
      addTab(targetName, val) {
        let flag = this.editableTabs.some((v) => {
          return v.name === val.path;
        });
        if (!flag) {
          this.editableTabs.push({
            title: val.title,
            name: val.path,
          });
        }

        this.editableTabsValue = val.path;
        sessionStorage.setItem("tabs", JSON.stringify(this.editableTabs));
      },
      removeTab(targetName) {
        let tabs = this.editableTabs;
        let activeName = this.editableTabsValue;
        if (activeName === targetName) {
          tabs.forEach((tab, index) => {
            if (tab.name === targetName) {
              let nextTab = tabs[index + 1] || tabs[index - 1];
              if (nextTab) {
                activeName = nextTab.name;
              }
            }
          });
        }

        this.editableTabsValue = activeName;
        this.editableTabs = tabs.filter((tab) => tab.name !== targetName);
        this.$router.push(activeName);
        sessionStorage.setItem("tabs", JSON.stringify(this.editableTabs));
      },
      jump() {
        this.$router.push(this.editableTabsValue);
      },
    },
  };
</script>
<style lang="less">
  .el-aside {
    color: #333;
    text-align: center;
    line-height: 200px;
  }

  .el-main {
    color: #333;
  }

  a {
    text-decoration: none;
    color: #ccc;
  }

  .router-link-exact-active {
    color: orange;
  }
</style>