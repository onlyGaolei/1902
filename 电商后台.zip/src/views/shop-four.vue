<template>
  <div>
    <div class="top">
      <mian />
    </div>
    商品评论
    <div>
      <div>
        时间选择：
        <el-radio-group v-model="radio" @change="changeDate">
          <el-radio-button label="">全部</el-radio-button>
          <el-radio-button label="today">今天</el-radio-button>
          <el-radio-button label="yesterday">昨天</el-radio-button>
          <el-radio-button label="lately7">最近7天</el-radio-button>
          <el-radio-button label="lately30">最近30天</el-radio-button>
          <el-radio-button label="month">本月</el-radio-button>
          <el-radio-button label="year">本年</el-radio-button>
        </el-radio-group>
      </div>
      <div>
        评价状态：
        <el-select
          v-model="value1"
          clearable
          placeholder="请选择"
          @change="cha"
        >
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.msg"
            :value="item.id"
          >
          </el-option>
        </el-select>
        商品信息：<el-input
          v-model="value2"
          style="width: 150px"
          placeholder="请输入内容"
        ></el-input>
        <el-button type="primary" icon="el-icon-search" @click="SouFun1"
          >搜索</el-button
        >
        用户名称：<el-input
          v-model="value3"
          style="width: 150px"
          placeholder="请输入内容"
        ></el-input>
        <el-button type="primary" icon="el-icon-search" @click="SouFun2"
          >搜索</el-button
        >
      </div>
    </div>
    <div>
      <el-button type="primary" icon="el-icon-plus" @click="addFun"
        >添加虚拟品论</el-button
      >
    </div>
    <div>
      <el-table :data="tableData" border style="width: 100%">
        <el-table-column fixed prop="id" label="ID"> </el-table-column>
        <el-table-column prop="image" label="商品信息">
          <template slot-scope="scope">
            <div>
              <img :src="scope.row.image" alt="" />{{ scope.row.store_name }}
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="nickname" label="用户名称"> </el-table-column>
        <el-table-column sortable prop="score" label="评分"> </el-table-column>
        <el-table-column prop="comment" label="评价内容">
          <template slot-scope="scope">
            <div>
              <img :src="scope.row.avatar" alt="" />{{ scope.row.comment }}
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="merchant_reply_content" label="回复内容">
        </el-table-column>
        <el-table-column sortable prop="add_time" label="评价时间">
        </el-table-column>
        <el-table-column fixed="right" label="操作" width="100">
          <template slot-scope="scope">
            <el-button @click="handleClick(scope.row)" type="text" size="small"
              >回复</el-button
            >
            <el-button
              type="text"
              size="small"
              @click="DelFun(scope.$index, scope.row)"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div>
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="[5, 10, 15, 20]"
        :page-size="100"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total"
      >
      </el-pagination>
    </div>
    <div>
      <el-dialog
        :title="title"
        :visible.sync="dialogVisible"
        width="30%"
        :before-close="handleClose"
      >
        <span>
          <el-form ref="form" :model="form" label-width="80px">
            <el-form-item label="评论名称">
              <el-input v-model="form.name"></el-input>
            </el-form-item>
          </el-form>
        </span>
        <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="addFunok()">确 定</el-button>
        </span>
      </el-dialog>
    </div>
    <div>
      <el-dialog
        :title="title1"
        :visible.sync="dialogVisible1"
        width="30%"
        :before-close="handleClose"
      >
        <span>
          <el-form ref="form" :model="form" label-width="80px">
            <el-form-item label="评论">
              <el-input
                type="textarea"
                :rows="2"
                placeholder="请输入内容"
                v-model="form.content"
              >
              </el-input>
            </el-form-item>
          </el-form>
        </span>
        <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible1 = false">取 消</el-button>
          <el-button type="primary" @click="huifuOk()">确 定</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import mian from "../components/mianbao.vue";
import { shopDataDEl, getProductReplycontent } from "../api/index";
import http from "../utils/http";
export default {
  data() {
    return {
      radio: "",
      textarea: "",
      title1: "",
      dialogVisible: false,
      dialogVisible1: false,
      title: "",
      form: {
        name: "",
      },
      tableData: [],
      currentPage: 1,
      page: 1,
      limit: 5,
      total: 0,
      value1: "",
      value2: "",
      value3: "",
      contentid: "",
      store_name: "",
      account: "",
      product_id: 0,
      options: [
        { id: 0, msg: "未回复" },
        { id: 1, msg: "已回复" },
      ],
    };
  },
  created() {
    this.show();
  },
  components: {
    mian,
  },
  methods: {
    //切换数据
    changeDate() {
      // console.log(this.radio);
      this.data = this.radio;
      this.show();
    },
    //商品回复显示遮罩层
    handleClick(row) {
      this.title1 = "回复";
      this.contentid = row.id;
      this.dialogVisible1 = true;
    },
    //商品回复提交
    huifuOk() {
      this.dialogVisible1 = false;
      getProductReplycontent({
        id: this.contentid,
        content: this.form,
      }).then((res) => {
        console.log(res);
        this.show();
      });
    },
    //添加提交
    addFunok() {
      console.log("添加机提交");
    },
    //查询评价
    cha() {
      // console.log(this.value1);
      http
        .get(
          `adminapi/product/reply?is_reply=${this.value1}&data=&store_name=&account=&product_id=0&page=${this.page}&limit=${this.limit}`
        )
        .then((res) => {
          // console.log(res);
          this.tableData = res.data.list;
          this.total = res.data.count;
        });
    },
    show() {
      http
        .get(
          `adminapi/product/reply?is_reply=&data=${this.data}&store_name=${this.store_name}&account=${this.account}&product_id=${this.product_id}&page=${this.page}&limit=${this.limit}`
        )
        .then((res) => {
          // console.log(res);
          this.tableData = res.data.list;
          this.total = res.data.count;
        });
    },
    SouFun1() {
      http
        .get(
          `adminapi/product/reply?is_reply=&data=&store_name=${this.value2}&account=&product_id=0&page=${this.page}&limit=${this.limit}`
        )
        .then((res) => {
          // console.log(res);
          this.tableData = res.data.list;
          this.total = res.data.count;
        });
    },
    SouFun2() {
      http
        .get(
          `adminapi/product/reply?is_reply=&data=&store_name=${this.value3}&account=&product_id=0&page=${this.page}&limit=${this.limit}`
        )
        .then((res) => {
          // console.log(res);
          this.tableData = res.data.list;
          this.total = res.data.count;
        });
    },
    //添加虚拟数据
    addFun() {
      this.title = "添加";
      this.dialogVisible = true;
      console.log("添加虚拟数据");
    },
    //删除
    DelFun(index, row) {
      // console.log(index, row);
      shopDataDEl(row.id).then((res) => {
        // console.log(res);
        this.show();
      });
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      http
        .get(
          `adminapi/product/reply?is_reply=&data=&store_name=&account=&product_id=0&page=${this.page}&limit=${val}`
        )
        .then((res) => {
          // console.log(res);
          this.tableData = res.data.list;
          this.total = res.data.count;
        });
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      http
        .get(
          `adminapi/product/reply?is_reply=&data=&store_name=&account=&product_id=0&page=${val}&limit=${this.limit}`
        )
        .then((res) => {
          // console.log(res);
          this.tableData = res.data.list;
          this.total = res.data.count;
        });
    },
    handleClose(done) {
      this.dialogVisible = false;
    },
  },
};
</script>
<style lang="less">
img {
  width: 50px;
  height: 50px;
}
</style>