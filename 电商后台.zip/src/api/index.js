import { post, get } from '../utils/http'
import http from '../utils/http'

//登录接口
export function loginFun(data) {
    return post('/adminapi/login', data)
}
//主页 头部数据
export function indexTopFun(data) {
    return get('adminapi/home/header', data)
}

//商品管理  商品顶部信息
export function shop_oneOne(data) {
    return get('adminapi/product/product/type_header', data)
}
//商品管理  商品添加input分类数据
export function shop_oneinputAdd(data) {
    return get('adminapi/product/category/tree/1', data)
}
//商品管理 商品上传
export function shop_oneupladAdd(name) {
    return get(`adminapi/file/category?name=${name}`)
}

//商品管理  商品数据
export function shop_oneTwo(data) {
    return get('adminapi/product/product', data)
}
//商品管理  商品下拉查询数据
export function shop_oneThree(val) {
    return get(`adminapi/product/category/tree/${val}`)
}
//商品管理移到回收站
export function huishouzhan(id) {
    return http.delete(`adminapi/product/product/${id}`)
}
//商品分类  商品分类数据
export function shop_twoOne(data) {
    return get('/adminapi/product/category', data)
}
//商品分类  商品分类状态查询数据
// export function shop_twoTWo(data) {
//     return http.put('/adminapi/product/category/set_show/13/1', data)
// }

//分类上传
export function shop_twoUplad(data) {
    return get('/adminapi/file/category?name=', data)
}
//分类遮罩层头部
export function shop_top() {
    return get('/adminapi/product/category/create')
}
//分类确认添加:
export function addok(data) {
    return post("adminapi/product/category.html", data)
    /*is_show	number		0:不显示  1:显示
    cate_name	string		名称
    sort	number		排序
    pid	number	 	
    pic	string		图片*/
}
//商品分类删除
export function shop_Del(id, data) {
    return http.delete(`/adminapi/product/category/${id}`, data)
}
//商品分类显示遮罩层编辑:
export function shop_editFun(id) {
    return get(`/adminapi/product/category/${id}`)
}
//商品分类编辑:
export function shop_edit(val) {
    return http.put(`/adminapi/product/category/${val.id}`, val.data)
}

//商品评论 删除
export function shopDataDEl(id) {
    return http.delete(`adminapi/product/reply/${id}`)
}
// 商品评论回复
export function getProductReplycontent(val) {
    return http.put(`/adminapi/product/reply/set_reply/${val.id}`, val.content)
}

//商品规格  商品规格数据渲染
export function shop_fourOne(data) {
    return get('adminapi/product/product/rule', data)
}
//商品规格  商品规格删除数据
export function shop_fourDel(data) {
    return get('adminapi/product/product/rule/delete', data)
}
//商品规格  商品规格搜索数据
export function shop_fourSerach(data) {
    return get('adminapi/product/product/rule', data)
}
//商品规格 删除
export function shop_fiveDelete(id) {
    return http.delete('adminapi/product/product/rule/delete', { params: id })
}
//商品规格 添加
export function shop_fiveTian(data) {
    return http.post(`adminapi/product/product/rule/0`, data)
}
//订单管理 头部
export function orderTop(data) {
    return get('adminapi/order/chart', data)
}
//订单管理 列表
export function orderData(data) {
    return get('adminapi/order/list', data)
}
//用户管理 列表
export function userData(data) {
    return get('adminapi/user/user', data)
}
//用户管理 编辑回显
export function edit(uid, data) {
    return get('/adminapi/user/user/' + uid + '/edit', data)
}
//用户管理 编辑回填确定
export function editFun(data) {
    return http.put('/adminapi/user/user/9.html', data)
}


//用户等级 列表
export function userTwoData(data) {
    return get('adminapi/user/user_level/vip_list', data)
}
//用户分组 列表
export function userThreeData(data) {
    return get('adminapi/user/user_group/list', data)
}
//用户标签 列表
export function userFourData(data) {
    return get('adminapi/user/user_label', data)
}

//分销设置 数据
export function DistributionSetData(data) {
    return get('adminapi/setting/config/edit_basics?tab_id=9', data)
}
//分销修改 提交
export function DistributionSetedit(data) {
    return post('adminapi/setting/config/save_basics', data)
}